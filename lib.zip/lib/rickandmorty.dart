import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class RickAndMortyPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Rick and Morty')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => CharacterPage()),
                );
              },
              child: Text('Показать рандомного персонажа'),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => EpisodePage()),
                );
              },
              child: Text('Показать рандомный эпизод'),
            ),
          ],
        ),
      ),
    );
  }
}

class CharacterPage extends StatefulWidget {
  @override
  _CharacterPageState createState() => _CharacterPageState();
}

class _CharacterPageState extends State<CharacterPage> {
  String _characterName = '';
  String _characterImage = '';

  Future<void> _fetchRandomCharacter() async {
    final response = await http.get(Uri.parse('https://rickandmortyapi.com/api/character/${_generateRandomNumber(671)}'));
    if (response.statusCode == 200) {
      final jsonData = json.decode(response.body);
      setState(() {
        _characterName = jsonData['name'];
        _characterImage = jsonData['image'];
      });
    } else {
      throw Exception('Ошибка загрузки персонажа');
    }
  }

  int _generateRandomNumber(int max) => 1 + DateTime.now().microsecondsSinceEpoch % max;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Рандомный песонаж')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            if (_characterName.isNotEmpty) ...[
              Image.network(_characterImage),
              SizedBox(height: 20),
              Text(
                'Персонаж:',
                style: TextStyle(fontSize: 20),
              ),
              SizedBox(height: 10),
              Text(
                _characterName,
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              ),
            ],
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _fetchRandomCharacter,
              child: Text('Показать рандомного персонажа'),
            ),
          ],
        ),
      ),
    );
  }
}

class EpisodePage extends StatefulWidget {
  @override
  _EpisodePageState createState() => _EpisodePageState();
}

class _EpisodePageState extends State<EpisodePage> {
  String _episodeName = '';
  String _episodeImage = '';

  Future<void> _fetchRandomEpisode() async {
    final response = await http.get(Uri.parse('https://rickandmortyapi.com/api/episode/${_generateRandomNumber(41)}'));
    if (response.statusCode == 200) {
      final jsonData = json.decode(response.body);
      setState(() {
        _episodeName = jsonData['name'];
        _episodeImage = 'https://rickandmortyapi.com/api/character/avatar/${_generateRandomNumber(671)}.jpeg';
      });
    } else {
      throw Exception('Ошибка загрузки эпизода');
    }
  }

  int _generateRandomNumber(int max) => 1 + DateTime.now().microsecondsSinceEpoch % max;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Рандомный эпизод')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            if (_episodeName.isNotEmpty) ...[
              Image.network(_episodeImage),
              SizedBox(height: 20),
              Text(
                'Название эпизода:',
                style: TextStyle(fontSize: 20),
              ),
              SizedBox(height: 10),
              Text(
                _episodeName,
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              ),
            ],
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _fetchRandomEpisode,
              child: Text('Показать эпизод'),
            ),
          ],
        ),
      ),
    );
  }
}