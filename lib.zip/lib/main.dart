import 'package:flutter/material.dart';
import 'auth_page.dart';

void main() {
  runApp(MaterialApp(
    home: AuthPage(),
  ));
}